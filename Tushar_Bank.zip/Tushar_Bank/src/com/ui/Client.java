package com.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.etities.Bank;
import com.exception.BankingException;
import com.service.BankService;
import com.service.BankServiceImpl;

public class Client {
	static BankService service = new BankServiceImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice = 0, choice1 = 0, choice2 = 0;
		try (Scanner scan = new Scanner(System.in)) {
			do {
				System.out
						.println("***********************************************");
				System.out
						.println("**                                           **");
				System.out.println("**         		Welcome to Bank   	       **");
				System.out
						.println("**                                           **");
				System.out
						.println("***********************************************");
				System.out.println("\n\n\n\n");
				System.out.print("1: Create new account : ");
				System.out.print("2: Login to your account : ");
				System.out.println("Enter Choice :: ");
				choice = scan.nextInt();
				switch (choice) {
				case 1:
					System.out
							.println("***********************************************");
					System.out
							.println("**                                           **");
					System.out
							.println("**            New Customer form              **");
					System.out
							.println("**                                           **");
					System.out
							.println("***********************************************");
					Bank bank = addDetails();
					if (bank != null) {
						try {
							int id = service.addCustomer(bank);
							System.out.println("Your account number is  = "
									+ id);
						} catch (BankingException e) {
							System.out.println(e.getMessage());
						}
					}
					break;
				case 2:
					System.out
							.println("***********************************************");
					System.out
							.println("**                                           **");
					System.out
							.println("**         		 Bank Login page           **");
					System.out
							.println("**                                           **");
					System.out
							.println("***********************************************");
					Bank bank1 = loginDetails();
					String username = bank1.getUserName();
					String password = bank1.getPassword();
					if (username.equals("admin") && password.equals("admin")) {
						do {
							System.out
									.println("***********************************************");
							System.out
									.println("**                                           **");
							System.out
									.println("**           Welcome Tushar Gagerna          **");
							System.out
									.println("**                                           **");
							System.out
									.println("***********************************************");

							System.out.println("\n \n");
							System.out
									.println("Select an operation to perform \n 1:See all customer details 2: Remove customer");
							choice1 = scan.nextInt();
							switch (choice1) {
							case 1:
								try {
									ArrayList<Bank> list = service
											.getAllCustomer();
									System.out.println(list);
								} catch (BankingException e) {
									System.out.println(e.getMessage());
								}
								break;
							case 2:
								System.out
										.print("Enter the account number you want to delete : ");
								int accNumber = scan.nextInt();
								try {
									Bank bank2 = service
											.removeCustomer(accNumber);
									System.out.println("Record Deleted "
											+ bank2);
								} catch (BankingException e) {
									System.out.println(e.getMessage());
								}
								break;
							}
							System.out
									.println("Do you want to perform more operation : 1-yes 0-no");
							choice = scan.nextInt();
						} while (choice != 0);

					} else {
						try {
							long id = 0;
							id = service.existCustomer(username, password);
							if (id == 0) {
								System.out
										.println("Username and password does not match!");
								continue;
							} else {
								System.out.println("Welcome " + username
										+ ". Your account number is -> " + id);
								do {

									System.out
											.println("\n 1. View your current balance \n 2. Withdraw amount \n 3. Deposit Amount ");
									choice2 = scan.nextInt();
									switch (choice2) {
									case 1:
										double balance = service.getBalance(id);
										System.out
												.println("Your current balance is : "
														+ balance);
										break;
									case 2:
										System.out
												.println("Enter the amount you want to withdraw : ");
										double amt = scan.nextInt();
										try {
											Bank bank2 = service.withdraw(id,
													amt);
										} catch (BankingException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 3:
										System.out
												.println("Enter the amount you want to deposit : ");
										double amount = scan.nextInt();
										try {
											Bank bank2 = service.deposit(id,
													amount);
										} catch (BankingException e) {
											System.out.println(e.getMessage());
										}
										break;
									}
									System.out
											.print("If you want to continue with account press 1 or press 0 to go to login page : ");
									choice2 = scan.nextInt();
								} while (choice2 != 0);
							}
						} catch (BankingException e) {
							System.out.println(e.getMessage());
						}
					}
					break;
				}
				System.out.println("Do you want to continue 1-yes 0-no");
				choice = scan.nextInt();
			} while (choice != 0);
		}

	}

	public static Bank loginDetails() {
		Bank bank = null;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter username :: ");
		String name = scan.next();
		System.out.println("Enter password");
		String pwd = scan.next();
		bank = new Bank();
		bank.setUserName(name);
		bank.setPassword(pwd);
		return bank;
	}

	public static Bank addDetails() {
		Bank bank = null;
		Scanner scan = new Scanner(System.in);

		while (true) {
			System.out.print("Enter name :: ");
			String name = scan.next();
			if (!service.validateName(name)) {
				System.out
						.println("Name should have first letter capital and rest all small with minimum of 3 letters like Tushar");
				continue;
			} else {
				while (true) {
					System.out.print("Enter your email address :: ");
					String email = scan.next();
					if (!service.validateEmail(email)) {
						System.out
								.print("Email format should be example@xyz.org");
						continue;
					} else {
						System.out.println("Enter your address :: ");
						String address = scan.next();
						System.out.println("Enter the username to login :: ");
						String userName = scan.next();

						while (true) {
							System.out.print("Enter your password :: ");
							String password = scan.next();
							if (!service.validatePassword(password)) {
								System.out
										.println("It should be less than 8 characters, doesn't contain digits or upper case characters and characters ~ in not allowed");
								continue;
							} else {
								while (true) {
									System.out
											.print("Enter the account type :: ");
									String accountType = scan.next();
									if (!service
											.validateAccountType(accountType)) {
										System.out
												.println("It should be 'savings' or 'current'");
										continue;
									} else {
										System.out
												.println("Select one security question \n 1: In what county were you born? \n 2: What is your oldest cousin�s first name? \n 3: What is the title and artist of your favorite song? \n 4: What is your oldest sibling�s middle name? \n 5: In what city or town did your mother and father meet?");
										int value = scan.nextInt();
										System.out
												.println("Enter your security password :: ");
										String securityQues = scan.next();
										bank = new Bank();
										bank.setFirstName(name);
										bank.setEmailId(email);
										bank.setAddress(address);
										bank.setUserName(userName);
										bank.setPassword(password);
										bank.setValue(value);
										bank.setQuestionPwd(securityQues);
										bank.setAccountType(accountType);
									}
									break;
								}
							}
							break;
						}
					}
					break;
				}
			}
			break;
		}
		return bank;
	}
}