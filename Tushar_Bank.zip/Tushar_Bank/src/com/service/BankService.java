package com.service;

import java.util.ArrayList;

import com.etities.Bank;
import com.exception.BankingException;

public interface BankService {

	int addCustomer(Bank bank) throws BankingException;
	Bank removeCustomer(int custId) throws BankingException;
	Bank getCustomerById(long custId) throws BankingException;
	ArrayList<Bank>getAllCustomer() throws BankingException;
	Bank withdraw(long id, double amount) throws BankingException;
	Bank deposit(long custId, double amount) throws BankingException;
	long existCustomer(String userName, String pass) throws BankingException;
	double getBalance(long custId) throws BankingException;
	Bank getCustomerUpdate(long custId) throws BankingException;
	
	public boolean validateName(String name);
	public boolean validateEmail(String email);
	public boolean validatePanCard(String panCard);
	public boolean validatePassword(String password);
	public boolean validateAccountType(String accountType);
}
