package com.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.dao.BankDao;
import com.dao.BankDaoImpl;
import com.etities.Bank;
import com.exception.BankingException;

public class BankServiceImpl implements BankService {

	BankDao dao;

	public void setDao(BankDao Dao) {
		this.dao = dao;
	}

	public BankServiceImpl() {
		dao = new BankDaoImpl();
	}

	@Override
	public int addCustomer(Bank bank) throws BankingException {
		return dao.addCustomer(bank);
	}

	@Override
	public Bank removeCustomer(int custId) throws BankingException {
		return dao.removeCustomer(custId);
	}

	@Override
	public Bank getCustomerById(long custId) throws BankingException {
		return dao.getCustomerById(custId);
	}

	@Override
	public ArrayList<Bank> getAllCustomer() throws BankingException {
		
		return dao.getAllCustomer();
	}

	@Override
	public Bank withdraw(long custId, double amount) throws BankingException {
		return dao.withdraw(custId, amount);
	}

	@Override
	public boolean validateName(String name) {
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if (Pattern.matches(pattern, name)) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		String pattern = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@"
				+ "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
		if (Pattern.matches(pattern, email)) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean validatePanCard(String panCard) {
		String pattern = "[A-Z0-9]";
		if (Pattern.matches(pattern, panCard)) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean validatePassword(String password) {
		String pattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
		if (Pattern.matches(pattern, password)) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateAccountType(String accountType) {
		String pattern = "savings";
		String pattern1 = "current";
		if (Pattern.matches(pattern, accountType)) {
			return true;
		} else if (Pattern.matches(pattern1, accountType)) {
			return true;
		} else
			return false;
	}

	@Override
	public long existCustomer(String userName, String pass)
			throws BankingException {
		return dao.existCustomer(userName, pass);
	}

	@Override
	public Bank deposit(long custId, double amount) throws BankingException {
		return dao.deposit(custId, amount);
	}

	@Override
	public double getBalance(long custId) throws BankingException {
		return dao.getBalance(custId);
	}

	@Override
	public Bank getCustomerUpdate(long custId) throws BankingException {
		return dao.getCustomerUpdate(custId);
	}

}
