package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.etities.Bank;
import com.exception.BankingException;
import com.logger.MyLogger;
import com.util.DBUtil;

public class BankDaoImpl implements BankDao {

	Connection con;
	Logger logger;

	public BankDaoImpl() {
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}

	public int getCustomerId() throws BankingException {
		logger.info("In getEmployeeId");
		int id = 0;
		String qry = "select account_id_seq.currval from dual";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if (rs.next()) {
				id = rs.getInt(1);
				logger.info("Got Customer with id " + id);
			}
		} catch (SQLException e) {
			logger.error("error " + e.getMessage());
			throw new BankingException(e.getMessage());
		}
		logger.info("Completed with get Customer ID");
		return id;

	}

	@Override
	public int addCustomer(Bank bank) throws BankingException {
		logger.info("In Add Employee");
		logger.info("Input is " + bank);
		int id = 0;
		String qry1 = "insert into Customer values(acc_id_seq.nextval,?,?,?)";
		String qry = "insert into Account_Master values(account_id_seq.nextval,?,0,sysdate)";
		String qry2 = "insert into User_Table values(accounts_id_seq.nextval,?,?,?,?,'N')";
		String name = bank.getFirstName();
		String email = bank.getEmailId();
		String address = bank.getAddress();
		String accountType = bank.getAccountType();
		String userName = bank.getUserName();
		String password=bank.getPassword();
		int value=bank.getValue();
		String ques=null;
		switch(value) {
			case 1: 
				ques="In what county were you born?";
				break;
			case 2: 
				ques="What is your oldest cousin�s first name?";
				break;
			case 3: 
				ques="What is the title and artist of your favorite song?";
				break;
			case 4: 
				ques="What is your oldest sibling�s middle name?";
				break;
			case 5: 
				ques="In what city or town did your mother and father meet?";
				break;
		}
		String questionPwd=bank.getPassword();
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, accountType);
			int row = pstmt.executeUpdate();
			PreparedStatement pstmt1 = con.prepareStatement(qry1);
			pstmt1.setString(1, name);
			pstmt1.setString(2, email);
			pstmt1.setString(3, address);
			int row1=pstmt1.executeUpdate();
			PreparedStatement pstmt2 = con.prepareStatement(qry2);
			pstmt2.setString(1, userName);
			pstmt2.setString(2,password);
			pstmt2.setString(3, ques);
			pstmt2.setString(4, questionPwd);
			int row2=pstmt2.executeUpdate();
			if (row > 0 && row1>0 && row2>0) {
				id = getCustomerId();
				logger.info("inserted successfully and account number is " + id);
			} else
				throw new BankingException("Unable to add customer details " + bank);
		} catch (SQLException e) {
			logger.error("error in insert = " + e.getMessage());
			throw new BankingException(e.getMessage());
		}
		return id;
	}

	@Override
	public Bank removeCustomer(int custId) throws BankingException {
		Bank bank=null;
		String qry = "delete from Customer where Account_ID=?";
		try{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1,custId);
			bank = getCustomerById(custId);
			int row = pstmt.executeUpdate();
			if(bank ==null)
			{
				throw new BankingException("Customer with account number "+custId+" not found");
			}
			else if(row>0)
			{
				System.out.println("Deleted customer with account number = "+custId);
			}
		}
			catch(SQLException e)
			{
				throw new BankingException(e.getMessage());
			}
		return bank;
	}

	@Override
	public Bank getCustomerById(long custId) throws BankingException {
		Bank bank;
		String qry = "select * from Customer where Account_Id=?";
		try{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setLong(1,custId);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				long id = rs.getLong(1);
				String name= rs.getString(2);
				String email = rs.getString(3);
				String address=rs.getString(4);
				bank = new Bank(id,name,email,address);
			}
			else
				throw new BankingException("Customer with account number "+custId+" not found");
		}
			catch(SQLException e)
			{
				throw new BankingException(e.getMessage());
			}
		return bank;
	}

	@Override
	public ArrayList<Bank> getAllCustomer() throws BankingException {
		ArrayList<Bank>list = new ArrayList<Bank>();
		String qry = "select * from Customer";
		try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name= rs.getString(2);
				String email = rs.getString(3);
				String address=rs.getString(4);
				Bank bank = new Bank(id,name,email,address);
				list.add(bank);
			}
		}
			catch(SQLException e)
			{
				throw new BankingException(e.getMessage());
			}
		return list;
	}

	@Override
	public Bank withdraw(long custId, double amount) throws BankingException {
		Bank bank = getCustomerUpdate(custId);
		if(bank==null)
		{
			throw new BankingException("Employee with id "+custId+" not found");
		}
		else 
		{
			String qry = "update Account_Master set account_balance=? where account_id=?";
			try{
				PreparedStatement pstmt = con.prepareStatement(qry);
				pstmt.setDouble(1,bank.getBalance()-amount);
				pstmt.setLong(2, custId);
				int row = pstmt.executeUpdate();
				
				if(row>0)
				{
					System.out.println("updated successfully");
					bank = getCustomerUpdate(custId);
				}
				else
					throw new BankingException("Customer with id "+custId+" not found");
			}
				catch(SQLException e)
				{
					throw new BankingException(e.getMessage());
				}
		}
		return bank;
	}

	@Override
	public long existCustomer(String userName, String pass)
			throws BankingException {
		long id = 0;
		String qry="select account_id from user_table where user_name=? and login_password=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1,userName);
			pstmt.setString(2,pass);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				id = rs.getLong(1);
				Bank bank = new Bank(id);
				logger.info("Got Customer with id " + id);
			}
		} catch (SQLException e) {
			logger.error("error " + e.getMessage());
			throw new BankingException(e.getMessage());
		}
		logger.info("Completed with get Customer ID");
		return id;
	}

	@Override
	public Bank deposit(long custId, double amount) throws BankingException {
		Bank bank = getCustomerUpdate(custId);
		if(bank==null)
		{
			throw new BankingException("Customer with id "+custId+" not found");
		}
		else 
		{
			String qry = "update Account_Master set account_balance=? where account_id=?";
			try{
				PreparedStatement pstmt = con.prepareStatement(qry);
				pstmt.setDouble(1,bank.getBalance()+amount);
				pstmt.setLong(2, custId);
				int row = pstmt.executeUpdate();
				if(row>0)
				{
					System.out.println("updated successfully");
					bank = getCustomerUpdate(custId);
				}
				else
					throw new BankingException("Customer with id "+custId+" not found");
			}
				catch(SQLException e)
				{
					throw new BankingException(e.getMessage());
				}
		}
		return bank;
	}

	@Override
	public double getBalance(long custId) throws BankingException {
		double balance = 0;
		String qry="select account_balance from Account_Master where account_id=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setLong(1,custId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				balance = rs.getLong(1);
				Bank bank = new Bank(balance);
				logger.info("Got Customer with balance ->> " + balance);
			}
		} catch (SQLException e) {
			logger.error("error " + e.getMessage());
			throw new BankingException(e.getMessage());
		}
		logger.info("Completed with get balance");
		return balance;
	}

	@Override
	public Bank getCustomerUpdate(long custId) throws BankingException {
		Bank bank;
		String qry = "select * from Account_Master where Account_Id=?";
		try{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setLong(1,custId);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				long id = rs.getLong(1);
				String accountType = rs.getString(2);
				double balance= rs.getInt(3);
				bank = new Bank(id,accountType,balance);
			}
			else
				throw new BankingException("Customer with account number "+custId+" not found");
		}
			catch(SQLException e)
			{
				throw new BankingException(e.getMessage());
			}
		return bank;
	}

}
