package com.dao;

import java.util.ArrayList;

import com.etities.Bank;
import com.exception.BankingException;

public interface BankDao {
	
	int addCustomer(Bank bank) throws BankingException;
	Bank removeCustomer(int custId) throws BankingException;
	Bank getCustomerById(long custId) throws BankingException;
	ArrayList<Bank>getAllCustomer() throws BankingException;
	Bank withdraw(long custId, double amount) throws BankingException;
	Bank deposit(long custId, double amount) throws BankingException;
	long existCustomer(String userName, String pass) throws BankingException;
	double getBalance(long custId) throws BankingException;
	Bank getCustomerUpdate(long custId) throws BankingException;
}
