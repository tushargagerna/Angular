package com.etities;

import java.time.LocalDate;
import java.util.Date;

public class Bank {

	private String firstName;
	private String lastName;
	private long contactNo;
	private long accountNo;
	private String address;
	private String emailId;
	private String accountType;
	private double balance;
	private String panCard;
	private String userName;
	private String password;
	private String question;
	private String questionPwd;
	private String lock;
	private LocalDate open_date;
	private String trans_desc;
	private int tranAmount;
	private String transType;
	private int value;

	public Bank() {

	}

	public LocalDate getOpen_date() {
		return open_date;
	}

	public void setOpen_date(LocalDate open_date) {
		this.open_date = open_date;
	}

	public String getTrans_desc() {
		return trans_desc;
	}

	public void setTrans_desc(String trans_desc) {
		this.trans_desc = trans_desc;
	}

	public int getTranAmount() {
		return tranAmount;
	}

	public void setTranAmount(int tranAmount) {
		this.tranAmount = tranAmount;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getQuestionPwd() {
		return questionPwd;
	}

	public void setQuestionPwd(String questionPwd) {
		this.questionPwd = questionPwd;
	}

	public String getLock() {
		return lock;
	}

	public void setLock(String lock) {
		this.lock = lock;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getContactNo() {
		return contactNo;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getPancard() {
		return panCard;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public Bank(long accountNo, String firstName, String emailId, String address) {
		super();
		this.firstName = firstName;
		this.accountNo = accountNo;
		this.address = address;
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "Bank [firstName=" + firstName + ", accountNo=" + accountNo
				+ ", address=" + address + ", emailId=" + emailId + "]\n";
	}

	public Bank(long accountNo) {
		super();
		this.accountNo = accountNo;
	}

	public Bank(double balance) {
		super();
		this.balance = balance;
	}

	public Bank(long accountNo, String accountType, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
	}

}
