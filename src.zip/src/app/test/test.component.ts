import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  public myID="test ID";
  public isDisabled="true";
  public hasError="true";//if true property will be applied.
  public isSpecial="true";
  public greeting ="";
  public name="";
  public messageClass = {
    "text-danger":this.hasError,
    "text-success":!this.hasError,
    "text-special":this.isSpecial
  }
  public style = {
    color: "blue",
    fontStyle:"italic"
  }
  constructor() { }

  ngOnInit() {
  }
onClick(event)
{
  console.log('Welcome to Mumbai')
  this.greeting="Welcome to mumbai";
}
  greetUser()
  {
    return "Hello " +this.name;
  }
  logMessage(value){
    console.log(value);
  }
}
