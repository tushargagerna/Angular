import {Component,OnInit} from '@angular/core';
import {Customer} from './Customer';
import {CustomerService} from './customer.service';


@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html',
    providers:[CustomerService]
})
export class EmployeeList implements  OnInit{
    
    employees:Customer[];
    statusmessage:string;


constructor(private empservice:CustomerService) {}
ngOnInit(): void {
    this.empservice.getAllEmployee().subscribe((employeeData)=>this.employees=employeeData,
    (error)=>{
        this.statusmessage="Problem with service check server"
           // console.error(error);
    }    
    );
 
}
delete(id:number):void{
    this.empservice.deleteEmployeeId(id).subscribe((employeeData)=>this.employees=employeeData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
}
 
}