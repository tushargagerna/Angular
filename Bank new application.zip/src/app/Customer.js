"use strict";
var Customer = (function () {
    function Customer() {
    }
    return Customer;
}());
exports.Customer = Customer;
