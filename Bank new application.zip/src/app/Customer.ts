export class Customer{
    accountNumber:Number;
	name:String;
	emailId: String ;
	dateOfBirth: String ;
	address: String ;
	city: String ;
	country: String ;
	mobileNo: String ;
	loginId: String ;
	password: String ;

}