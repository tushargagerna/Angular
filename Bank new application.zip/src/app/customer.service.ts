import { Injectable } from '@angular/core';
import {Customer} from './Customer';
import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
//import "rxjs/add/operator/throw"
@Injectable()
export class CustomerService{
   
    constructor(private http:Http) {}
  //For All Application check your your REST URI-PORT & Path   
    //GET ALL -with Banking Application-http://localhost:8086/BankingApplication/rest/bank/employee
    getAllEmployee():Observable<Customer[]> 
{ return  this.http.get("http://localhost:8086/BankingApplication/rest/bank").
        map((response:Response)=><Customer[]>response.json())
        .catch(this.handleError);
    }
    handleError(error: Response){
        console.error(error);
        return Observable.throw(error);
    }
    
    
    //delete data--with Banking Application-http://localhost:8086/BankingApplication/rest/bank/delete/
    deleteEmployeeId(data:number): Observable<Customer[]> {
        console.log(data)
        return this.http
            .delete('http://localhost:8086/BankingApplication/rest/bank/delete/'+data)
            .map((response:Response)=><Customer[]>response.json())
            .catch(this.handleError);
        }
        handleErrorDelete(error: Response){
            console.error(error);
            return Observable.throw(error);
        }
        //add data--with Banking Application-http://localhost:8086/BankingApplication/rest/bank/create/
        addEmployee(data:Customer): Observable<Customer[]> {
            let empData=JSON.stringify(data);
            alert(empData);
            let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
            let options = new RequestOptions({ headers: cpHeaders });
            
            return this.http
                .post('http://localhost:8086/BankingApplication/rest/bank/create/',empData,options)
                .map((success => success.status))
                .catch(this.handleError);
            }
            handleErrorAdd(error: Response){
                console.error(error);
                return Observable.throw(error);
            }
            //search data--with Banking Application-http://localhost:8086/BankingApplication/rest/bank/search/
            searchEmployeeId(data:number): Observable<Customer[]> {
                console.log(data)
                return this.http
                    .get('http://localhost:8086/BankingApplication/rest/bank/search/'+data)
                    .map((response:Response)=><Customer[]>response.json())
                    .catch(this.handleError);
                }
                handleErrorSearch(error: Response){
                    console.error(error);
                    return Observable.throw(error);
                }
                //update Data --with Banking Application-http://localhost:8086/BankingApplication/rest/bank/update/
                updateEmployee(data:Customer): Observable<Customer[]> {
                    let empData=JSON.stringify(data);
                    alert(empData);
                    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
                    let options = new RequestOptions({ headers: cpHeaders });
                    
                    return this.http
                        .put('http://localhost:8086/BankingApplication/rest/bank/update/',empData,options)
                        .map((success => success.status))
                        .catch(this.handleError);
                    }
                    handleErrorupdate(error: Response){
                        console.error(error);
                        return Observable.throw(error);
                    }
    }
 