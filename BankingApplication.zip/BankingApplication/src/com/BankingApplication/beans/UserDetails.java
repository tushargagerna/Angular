package com.BankingApplication.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="UserDetails")
@SequenceGenerator(name="seq", initialValue=1, allocationSize=1000)
public class UserDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq") 
	@Column(name = "acctNo")
	private int accountNumber;

	@Column(name = "name")
	private String name;

	@Column(name = "emailId")
	private String emailId;

	@Column(name = "dateOfBirth")
	private String dateOfBirth;

	@Column(name = "address")
	private String address;

	@Column(name = "city")
	private String city;

	@Column(name = "country")
	private String country;

	@Column(name = "mobileNo")
	private String mobileNo;

	@Column(name = "loginId")
	private String loginId;

	@Column(name = "password")
	private String password;

	
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserDetails(int accountNumber, String name, String emailId,
			String dateOfBirth, String address, String city, String country,
			String mobileNo, String loginId, String password) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.city = city;
		this.country = country;
		this.mobileNo = mobileNo;
		this.loginId = loginId;
		this.password = password;
	}

	public UserDetails() {
		super();
	}
	
	
	
}


