package com.BankingApplication.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AccountDetails")
public class AccountDetails {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "accountBalance")
	private String accountBalance;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}

	public AccountDetails(int id, String accountBalance) {
		super();
		this.id = id;
		this.accountBalance = accountBalance;
	}

	public AccountDetails() {
		super();
	}

	
	
}
