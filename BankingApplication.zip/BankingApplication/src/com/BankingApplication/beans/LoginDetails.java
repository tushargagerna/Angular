package com.BankingApplication.beans;
/*package com.cg.BankingApplication.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="LoginDetails")
public class LoginDetails {

	@Column(name = "uname")
	public String uname; 

	@Column(name = "password")
	public String password;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LoginDetails(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}

	public LoginDetails() {
		super();
	}
	
	
}
*/