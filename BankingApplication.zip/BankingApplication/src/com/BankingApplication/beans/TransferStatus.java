package com.BankingApplication.beans;
/*package com.cg.BankingApplication.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TransferStatus")
public class TransferStatus {

	@Column(name = "status")
	public String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TransferStatus(String status) {
		super();
		this.status = status;
	}

	public TransferStatus() {

	}

}
*/