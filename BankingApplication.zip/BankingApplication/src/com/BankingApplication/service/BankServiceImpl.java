package com.BankingApplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BankingApplication.beans.UserDetails;
import com.BankingApplication.dao.BankDAO;

@Transactional
@Service("bankService")
public class BankServiceImpl implements BankService{

	@Autowired
	BankDAO bankDao;

	@Override
	public void addCustomer(UserDetails user) {
		bankDao.addCustomer(user);
		
	}

	@Override
	public void removeCustomer(int id) {
		bankDao.removeCustomer(id);
		
	}

	@Override
	public UserDetails searchCustomer(int id) {
		return bankDao.searchCustomer(id);
	}

	@Override
	public void updateCustomer(UserDetails user) {
		bankDao.updateCustomer(user);
	}

	@Override
	public List<UserDetails> getAllCustomer() {
		return bankDao.getAllCustomer();
	}
	
	
}
