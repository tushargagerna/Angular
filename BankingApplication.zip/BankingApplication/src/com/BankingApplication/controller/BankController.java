package com.BankingApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.BankingApplication.beans.UserDetails;
import com.BankingApplication.service.BankService;

@RestController
public class BankController {

	@Autowired
	BankService bankService;

	/**
	 * Method fetches all user details supporting HTTP GET method
	 * 
	 * @param MODEL
	 * @return String - List Bank JSON
	 *         http://localhost:8086/BankingApplication/rest/bank
	 */

	@RequestMapping(value = "/bank",method = RequestMethod.GET,headers="Accept=application/json")
	public List<UserDetails> getAllCustomer() {
		return bankService.getAllCustomer();
	}

	@RequestMapping(value = "/bank/delete/{id}", headers = "Accept=application/json", method = RequestMethod.DELETE)
	public List<UserDetails> deleteCustomer(@PathVariable("id") int id) {
		System.out.println(id);
		bankService.removeCustomer(id);
		return bankService.getAllCustomer();
	}

	@RequestMapping(value = "/bank/create/", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", method = RequestMethod.POST)
	public List<UserDetails> createCustomer(@RequestBody UserDetails user) {

		System.out.println(user);
		bankService.addCustomer(user);
		return bankService.getAllCustomer();
	}

	@RequestMapping(value = "/bank/search/{id}", headers = "Accept=application/json", method = RequestMethod.GET)
	public UserDetails searchCustomer(@PathVariable("id") int id) {
		System.out.println("In search");
		return bankService.searchCustomer(id);
	}

	@RequestMapping(value = "/bank/update/", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", method = RequestMethod.PUT)
	public List<UserDetails> updateCustomer(@RequestBody UserDetails user) {

		System.out.println("Update");
		System.out.println(user);
		bankService.updateCustomer(user);
		return bankService.getAllCustomer();
	}

}
