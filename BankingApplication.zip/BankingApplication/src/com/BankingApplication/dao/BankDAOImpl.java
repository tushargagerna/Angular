package com.BankingApplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.BankingApplication.beans.UserDetails;

@Repository("bankDao")
public class BankDAOImpl implements BankDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addCustomer(UserDetails user) {
		entityManager.persist(user);
		entityManager.flush();
	}

	@Override
	public void removeCustomer(int id) {
		UserDetails user = entityManager.find(UserDetails.class, id);
		entityManager.remove(user);
	}

	@Override
	public UserDetails searchCustomer(int id) {
		return entityManager.find(UserDetails.class, id);
	}

	@Override
	public void updateCustomer(UserDetails user) {
		entityManager.merge(user);
	}

	@Override
	public List<UserDetails> getAllCustomer() {
		Query queryOne = entityManager.createQuery("select user FROM UserDetails user");
		List<UserDetails> allProduct = queryOne.getResultList();
		return allProduct;
	}

}
