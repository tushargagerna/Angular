package com.BankingApplication.dao;

import java.util.List;

import com.BankingApplication.beans.UserDetails;

public interface BankDAO {

	public void addCustomer(UserDetails user);
	public void removeCustomer(int id);
	public UserDetails searchCustomer(int id);
	public void updateCustomer(UserDetails user);
	public List<UserDetails> getAllCustomer();
}
